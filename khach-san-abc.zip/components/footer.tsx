export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-8">
          <div>
            <h3 className="text-2xl font-serif mb-4" style={{ fontFamily: "var(--font-playfair)" }}>
              KHÁCH SẠN ABC
            </h3>
            <p className="text-primary-foreground/80 leading-relaxed">
              Khách sạn 5 sao hàng đầu tại Sài Gòn, mang đến trải nghiệm nghỉ dưỡng đẳng cấp quốc tế.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-serif mb-4" style={{ fontFamily: "var(--font-playfair)" }}>
              Liên Kết Nhanh
            </h4>
            <ul className="space-y-2 text-primary-foreground/80">
              <li>
                <a href="#" className="hover:text-primary-foreground transition-colors">
                  Về Chúng Tôi
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition-colors">
                  Phòng & Suites
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition-colors">
                  Dịch Vụ
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition-colors">
                  Ưu Đãi
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-serif mb-4" style={{ fontFamily: "var(--font-playfair)" }}>
              Thông Tin Liên Hệ
            </h4>
            <ul className="space-y-2 text-primary-foreground/80">
              <li>123 Đồng Khởi, Quận 1</li>
              <li>TP. Hồ Chí Minh</li>
              <li>ĐT: 028.12345678</li>
              <li>Email: info@khachsanabc.vn</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8 text-center text-primary-foreground/60 text-sm">
          <p>&copy; 2025 Khách Sạn ABC. Bảo lưu mọi quyền.</p>
        </div>
      </div>
    </footer>
  )
}
