import { Card } from "@/components/ui/card"
import { Sparkles, Utensils, Wifi, Car } from "lucide-react"

const features = [
  {
    icon: Sparkles,
    title: "Phòng Cao Cấp",
    description: "Các phòng suite được thiết kế tinh tế với nội thất sang trọng và tầm nhìn toàn cảnh thành phố",
  },
  {
    icon: Utensils,
    title: "Ẩm Thực Đẳng Cấp",
    description: "Nhà hàng 5 sao phục vụ các món ăn quốc tế và Việt Nam do đầu bếp hàng đầu chế biến",
  },
  {
    icon: Wifi,
    title: "Tiện Nghi Hiện Đại",
    description: "WiFi tốc độ cao, phòng gym, spa và hồ bơi vô cực trên tầng thượng",
  },
  {
    icon: Car,
    title: "Dịch Vụ Đưa Đón",
    description: "Dịch vụ đưa đón sân bay và xe limousine cao cấp phục vụ 24/7",
  },
]

export function Features() {
  return (
    <section className="py-24 md:py-32 px-6 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2
            className="text-4xl md:text-5xl lg:text-6xl font-serif text-foreground mb-4"
            style={{ fontFamily: "var(--font-playfair)" }}
          >
            Tiện Nghi & Dịch Vụ
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Mọi chi tiết đều được chăm chút để mang đến trải nghiệm hoàn hảo nhất
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="p-8 hover:shadow-xl transition-all duration-300 border-border bg-card">
              <div className="mb-6">
                <div className="w-14 h-14 bg-secondary/10 rounded-full flex items-center justify-center">
                  <feature.icon className="w-7 h-7 text-secondary" />
                </div>
              </div>
              <h3
                className="text-xl font-serif mb-3 text-card-foreground"
                style={{ fontFamily: "var(--font-playfair)" }}
              >
                {feature.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
