export function Gallery() {
  const images = [
    {
      url: "/luxury-hotel-bedroom-with-city-view.jpg",
      title: "Phòng Deluxe",
    },
    {
      url: "/elegant-hotel-restaurant-interior.jpg",
      title: "Nhà Hàng",
    },
    {
      url: "/rooftop-infinity-pool-with-city-skyline.jpg",
      title: "Hồ Bơi Vô Cực",
    },
  ]

  return (
    <section className="py-24 md:py-32 px-6 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2
            className="text-4xl md:text-5xl lg:text-6xl font-serif text-foreground mb-4"
            style={{ fontFamily: "var(--font-playfair)" }}
          >
            Không Gian Sang Trọng
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Khám phá vẻ đẹp tinh tế trong từng góc của khách sạn
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {images.map((image, index) => (
            <div key={index} className="group relative overflow-hidden aspect-[4/3] cursor-pointer">
              <img
                src={image.url || "/placeholder.svg"}
                alt={image.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="text-2xl font-serif text-white" style={{ fontFamily: "var(--font-playfair)" }}>
                    {image.title}
                  </h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
