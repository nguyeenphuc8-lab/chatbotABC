import { Button } from "@/components/ui/button"
import { Phone } from "lucide-react"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img src="/luxury-5-star-hotel-lobby-with-elegant-chandelier-.jpg" alt="Khách Sạn ABC" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/60" />
      </div>

      {/* Navigation */}
      <nav className="absolute top-0 left-0 right-0 z-20 px-6 py-8 md:px-12">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="text-white">
            <h1
              className="text-2xl md:text-3xl font-serif tracking-wider"
              style={{ fontFamily: "var(--font-playfair)" }}
            >
              KHÁCH SẠN ABC
            </h1>
            <p className="text-xs md:text-sm tracking-widest mt-1 opacity-90">LUXURY HOTEL</p>
          </div>
          <Button
            variant="outline"
            className="bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white hover:text-primary transition-all duration-300"
          >
            <Phone className="w-4 h-4 mr-2" />
            Đặt Phòng
          </Button>
        </div>
      </nav>

      {/* Hero Content */}
      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        <h2
          className="text-5xl md:text-7xl lg:text-8xl font-serif text-white mb-6 leading-tight text-balance"
          style={{ fontFamily: "var(--font-playfair)" }}
        >
          Trải Nghiệm Đẳng Cấp
          <br />
          <span className="italic">Sang Trọng Bậc Nhất</span>
        </h2>
        <p className="text-lg md:text-xl text-white/90 mb-12 max-w-2xl mx-auto leading-relaxed text-pretty">
          Khám phá sự hoàn hảo tại khách sạn 5 sao giữa lòng Sài Gòn, nơi mỗi khoảnh khắc đều là một trải nghiệm đáng
          nhớ
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            size="lg"
            className="bg-secondary hover:bg-secondary/90 text-secondary-foreground px-8 py-6 text-base"
          >
            Khám Phá Ngay
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white hover:text-primary px-8 py-6 text-base"
          >
            Xem Phòng
          </Button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-3 bg-white/70 rounded-full" />
        </div>
      </div>
    </section>
  )
}
