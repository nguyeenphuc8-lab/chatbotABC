"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { MapPin, Phone, Mail, Clock } from "lucide-react"
import { useEffect } from "react"

const contactInfo = [
  {
    icon: MapPin,
    title: "Địa Chỉ",
    content: "123 Đồng Khởi, Quận 1, TP.HCM",
  },
  {
    icon: Phone,
    title: "Điện Thoại",
    content: "028.12345678",
  },
  {
    icon: Mail,
    title: "Email",
    content: "info@khachsanabc.vn",
  },
  {
    icon: Clock,
    title: "Giờ Làm Việc",
    content: "Phục vụ 24/7",
  },
]

export function Contact() {
  useEffect(() => {
    // Load chatbot script
    const script = document.createElement("script")
    script.src = "https://cdn.botpress.cloud/webchat/v3.3/inject.js"
    script.async = true
    document.body.appendChild(script)

    script.onload = () => {
      // @ts-ignore
      window.botpressWebChat?.init({
        composerPlaceholder: "Nhắn tin cho chúng tôi...",
        botConversationDescription: "Trợ lý ảo của Khách Sạn ABC",
        botId: "JSO49V20",
        hostUrl: "https://cdn.botpress.cloud/webchat/v3.3",
        messagingUrl: "https://messaging.botpress.cloud",
        clientId: "JSO49V20",
        webhookId: "your-webhook-id",
        lazySocket: true,
        themeName: "prism",
        botName: "Khách Sạn ABC",
        stylesheet: "https://webchat-styler-css.botpress.app/prod/code/...",
        frontendVersion: "v3.3",
        useSessionStorage: true,
        enableConversationDeletion: true,
        showPoweredBy: false,
      })
    }

    return () => {
      document.body.removeChild(script)
    }
  }, [])

  return (
    <section className="py-24 md:py-32 px-6 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2
            className="text-4xl md:text-5xl lg:text-6xl font-serif text-foreground mb-4"
            style={{ fontFamily: "var(--font-playfair)" }}
          >
            Liên Hệ Với Chúng Tôi
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Đội ngũ của chúng tôi luôn sẵn sàng phục vụ bạn
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {contactInfo.map((info, index) => (
            <Card
              key={index}
              className="p-6 text-center hover:shadow-lg transition-all duration-300 border-border bg-card"
            >
              <div className="mb-4 flex justify-center">
                <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center">
                  <info.icon className="w-6 h-6 text-secondary" />
                </div>
              </div>
              <h3
                className="font-serif text-lg mb-2 text-card-foreground"
                style={{ fontFamily: "var(--font-playfair)" }}
              >
                {info.title}
              </h3>
              <p className="text-muted-foreground text-sm">{info.content}</p>
            </Card>
          ))}
        </div>

        <div className="bg-muted/30 p-8 md:p-12 text-center">
          <h3 className="text-3xl font-serif mb-4 text-foreground" style={{ fontFamily: "var(--font-playfair)" }}>
            Đặt Phòng Ngay Hôm Nay
          </h3>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto leading-relaxed">
            Trải nghiệm dịch vụ 5 sao đẳng cấp quốc tế tại trung tâm Sài Gòn
          </p>
          <Button
            size="lg"
            className="bg-secondary hover:bg-secondary/90 text-secondary-foreground px-10 py-6 text-base"
          >
            Đặt Phòng Ngay
          </Button>
        </div>
      </div>
    </section>
  )
}
